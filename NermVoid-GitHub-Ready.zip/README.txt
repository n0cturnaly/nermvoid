NermVoid Android wrapper
URL: https://nermvoid.blogspot.com/
Icon: supplied user image
Status bar: transparent, dark/black system icons
Navigation bar: #AE1414, matching the dominant red of the supplied icon
Target SDK: 35
