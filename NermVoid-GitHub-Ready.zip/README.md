# NermVoid Android

Android WebView app for https://nermvoid.blogspot.com/

## Build on GitHub
1. Upload the contents of this project to a GitHub repository.
2. Open **Actions**.
3. Select **Build NermVoid APK**.
4. Press **Run workflow**.
5. Open the completed workflow and download the **NermVoid-APK** artifact.
6. Extract `app-debug.apk` and install it on the Android phone.

The project is configured for Android and works on Android 13. The status bar is transparent with dark icons, and the navigation bar uses the icon's red color.
